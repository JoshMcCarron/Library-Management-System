package userTypes;

public class Visitor extends User{

	public Visitor(String email, String password) {
		super(email, password);
		// TODO Auto-generated constructor stub
	}

}
