package userTypes;

public class NonFaculty extends User{

	public NonFaculty(String email, String password) {
		super(email, password);
		// TODO Auto-generated constructor stub
	}

}
