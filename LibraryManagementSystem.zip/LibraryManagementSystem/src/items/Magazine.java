package items;

public class Magazine extends PhysicalItem{

	public Magazine(int copies, String title) {
		super(copies, title);
		// TODO Auto-generated constructor stub
	}

}
