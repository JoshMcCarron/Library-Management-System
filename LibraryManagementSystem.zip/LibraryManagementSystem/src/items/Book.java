package items;

public class Book extends PhysicalItem{
	public Book(int copies, String title) {
		super(copies,title);
	}
}
