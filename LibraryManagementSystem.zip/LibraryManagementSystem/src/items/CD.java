package items;

public class CD extends PhysicalItem{

	public CD(int copies, String title) {
		super(copies, title);
		// TODO Auto-generated constructor stub
	}

}
