package items;

public class OnlineBook extends OnlineResource{

	public OnlineBook(String title) {
		super(title);
		// TODO Auto-generated constructor stub
	}

}
