package items;

public class Newsletter extends OnlineResource{

	public Newsletter(String title) {
		super(title);
		// TODO Auto-generated constructor stub
	}
	
	

}
